// Page code for the "Places" page (/places).
// Lists the destination and experience names members typed themselves,
// once a moderator has approved them.
//
// Required elements:
//   #placesRepeater   Repeater
//     inside each item:
//       #placeName     Text
//       #placeType     Text   (Destination / Experience)
//       #placeCount    Text   ("used in N vlogs")
//       #placeLink     Button (opens /places/{slug})
//   #placesCountText   Text
//   #placesEmptyText   Text   (hidden by default)
//   #filterAll, #filterDestinations, #filterExperiences   Buttons

import wixLocation from 'wix-location';
import { listPlaces } from 'backend/vlogPlaces';

let allPlaces = [];
let activeFilter = null; // null | 'destination' | 'experience'

$w.onReady(async function () {
  $w('#placesEmptyText').hide();
  $w('#placesRepeater').onItemReady(bindItem);

  $w('#filterAll').onClick(() => applyFilter(null));
  $w('#filterDestinations').onClick(() => applyFilter('destination'));
  $w('#filterExperiences').onClick(() => applyFilter('experience'));

  try {
    allPlaces = await listPlaces();
  } catch (err) {
    console.error('Places could not be loaded', err);
    allPlaces = [];
  }

  applyFilter(null);
});

function applyFilter(type) {
  activeFilter = type;
  const items = type ? allPlaces.filter((p) => p.placeType === type) : allPlaces;

  $w('#placesCountText').text = `${items.length} places`;

  if (items.length === 0) {
    $w('#placesRepeater').hide();
    $w('#placesEmptyText').text = 'No places here yet.';
    $w('#placesEmptyText').show();
    return;
  }

  $w('#placesEmptyText').hide();
  $w('#placesRepeater').data = items;
  $w('#placesRepeater').show();
}

function bindItem($item, itemData) {
  $item('#placeName').text = itemData.name || '';
  $item('#placeType').text = itemData.placeType === 'experience' ? 'Experience' : 'Destination';

  const n = itemData.usageCount || 0;
  $item('#placeCount').text = n === 1 ? 'Used in 1 vlog' : `Used in ${n} vlogs`;

  $item('#placeLink').onClick(() => wixLocation.to(`/places/${itemData.slug}`));
}
